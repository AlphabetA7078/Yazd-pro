package com.yazdpro.pdr;
import android.app.Activity;
import android.os.Bundle;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.*;
import android.view.*;
import android.widget.*;
import java.text.NumberFormat;
import java.util.Locale;

public class MainActivity extends Activity {
    EditText car,part,remove,depreciation,extra;
    Spinner vehicle,panel,job,damage;
    TextView result,history;
    SharedPreferences prefs;
    double amount=0;
    int ink=Color.rgb(29,39,55), teal=Color.rgb(20,112,125);

    public void onCreate(Bundle b){super.onCreate(b);prefs=getSharedPreferences("yp",0);ui();}
    int dp(int n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    void section(LinearLayout p,String s){TextView t=new TextView(this);t.setText(s);t.setTextSize(17);t.setTextColor(ink);t.setTypeface(null,1);t.setPadding(0,dp(17),0,dp(7));p.addView(t);}
    Spinner spin(LinearLayout p,String label,String[] vals){
        TextView l=new TextView(this);l.setText(label);l.setTextColor(ink);p.addView(l);
        Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,vals);a.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);s.setAdapter(a);p.addView(s,new LinearLayout.LayoutParams(-1,dp(48)));return s;
    }
    EditText field(LinearLayout p,String hint){
        EditText e=new EditText(this);e.setSingleLine(true);e.setHint(hint);e.setInputType(2);e.setTextSize(15);e.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL);e.setPadding(dp(10),0,dp(10),0);e.setBackgroundColor(Color.WHITE);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,dp(52));lp.setMargins(0,dp(5),0,dp(5));p.addView(e,lp);return e;
    }
    Button btn(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(-1);b.setAllCaps(false);b.setBackgroundTintList(ColorStateList.valueOf(c));return b;}
    void ui(){
        ScrollView sc=new ScrollView(this);LinearLayout p=new LinearLayout(this);p.setOrientation(1);p.setPadding(dp(18),dp(18),dp(18),dp(28));p.setBackgroundColor(0xfff6f8fa);p.setLayoutDirection( View.LAYOUT_DIRECTION_RTL);sc.addView(p);
        TextView title=new TextView(this);title.setText("YAZD PRO");title.setTextSize(28);title.setTypeface(null,1);title.setTextColor(ink);title.setGravity(17);p.addView(title);
        TextView sub=new TextView(this);sub.setText("قیمت‌گذاری تخصصی صافکاری و PDR");sub.setTextColor(teal);sub.setGravity(17);sub.setPadding(0,dp(5),0,dp(18));p.addView(sub);
        section(p,"مشخصات خودرو و قطعه");
        vehicle=spin(p,"خودرو",new String[]{"پراید","پژو ۲۰۶","پژو ۴۰۵","سمند","تیبا","ساینا","کوییک","دنا","پژو پارس","سایر"});
        panel=spin(p,"قطعه",new String[]{"درب جلو","درب عقب","گلگیر جلو","گلگیر عقب","کاپوت","سقف","صندوق","ستون","سایر"});
        job=spin(p,"نوع عملیات",new String[]{"PDR بدون رنگ","صافکاری با رنگ","ترکیبی"});
        damage=spin(p,"شدت آسیب",new String[]{"کم","متوسط","زیاد","خیلی زیاد"});
        section(p,"مبالغ به تومان");
        car=field(p,"قیمت روز خودرو");part=field(p,"قیمت قطعه");remove=field(p,"اجرت باز و بست قطعه");depreciation=field(p,"افت قیمت / خسارت");extra=field(p,"هزینه‌های جانبی");
        TextView f=new TextView(this);f.setText("فرمول: ۵۰٪ × مجموع مبالغ واردشده");f.setTextColor(ink);f.setPadding(dp(12),dp(12),dp(12),dp(12));f.setBackgroundColor(0xffeaf2f3);p.addView(f);
        Button calc=btn("محاسبه اجرت",teal);p.addView(calc);calc.setOnClickListener(v->calc());
        result=new TextView(this);result.setText("مبلغ برآوردی اجرت: —");result.setTextSize(21);result.setTypeface(null,1);result.setTextColor(ink);result.setGravity(17);result.setPadding(0,dp(20),0,dp(20));p.addView(result);
        LinearLayout row=new LinearLayout(this);row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);Button save=btn("ذخیره فاکتور",ink),copy=btn("کپی مبلغ",teal);row.addView(save,new LinearLayout.LayoutParams(0,dp(50),1));row.addView(copy,new LinearLayout.LayoutParams(0,dp(50),1));p.addView(row);
        save.setOnClickListener(v->save());copy.setOnClickListener(v->{if(amount>0){((ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("اجرت",money(amount)));Toast.makeText(this,"کپی شد",0).show();}});
        section(p,"سوابق قیمت‌گذاری");history=new TextView(this);history.setTextColor(ink);history.setPadding(dp(12),dp(12),dp(12),dp(12));history.setBackgroundColor(-1);p.addView(history);Button clear=btn("پاک کردن سوابق",0xff874242);p.addView(clear);clear.setOnClickListener(v->{prefs.edit().remove("h").apply();refresh();});refresh();setContentView(sc);
    }
    double val(EditText e){String s=e.getText().toString().replace(",","").replace("٬","").replace("،","");String fa="۰۱۲۳۴۵۶۷۸۹",ar="٠١٢٣٤٥٦٧٨٩";for(int i=0;i<10;i++){s=s.replace(fa.charAt(i),(char)('0'+i));s=s.replace(ar.charAt(i),(char)('0'+i));}try{return Double.parseDouble(s);}catch(Exception x){return 0;}}
    String money(double x){return NumberFormat.getIntegerInstance(new Locale("fa","IR")).format(Math.round(x))+" تومان";}
    void calc(){amount=.5*(val(car)+val(part)+val(remove)+val(depreciation)+val(extra));result.setText("مبلغ برآوردی اجرت:\n"+money(amount));}
    void save(){if(amount<=0)calc();if(amount<=0){Toast.makeText(this,"ابتدا مبالغ را وارد کن",0).show();return;}String r=vehicle.getSelectedItem()+" | "+panel.getSelectedItem()+" | "+job.getSelectedItem()+" | "+damage.getSelectedItem()+" | "+money(amount);prefs.edit().putString("h",r+"\n"+prefs.getString("h","")).apply();refresh();Toast.makeText(this,"ذخیره شد",0).show();}
    void refresh(){String h=prefs.getString("h","");history.setText(h.isEmpty()?"هنوز سابقه‌ای ثبت نشده است.":h);}
}
